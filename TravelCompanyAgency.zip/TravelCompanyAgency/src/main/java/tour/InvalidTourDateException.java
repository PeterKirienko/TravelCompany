package tour;

public class InvalidTourDateException extends Exception {
    public InvalidTourDateException(String Message) {
        super(Message);
    }
}
