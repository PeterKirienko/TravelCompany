package person;

public abstract class Person {
	public String name;
	public boolean hasVisa;
	public int age;
	
	public Person (String name, int age) {
		this.name = name;
		this.age = age;
	}

	public void pay(int price) {
		
	}

	public void swim() {
		
		
	}
}
