package person;

final class Girl extends Person {

	public Girl(String name, int age) {
		super(name, age);
	}

}

