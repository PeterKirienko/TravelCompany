package person;

public class Boy extends Person {

	public Boy(String name, int age) {
		super(name, age);
	}

}
