package interfaces;

public interface Swimming {
	public void swim();
}
