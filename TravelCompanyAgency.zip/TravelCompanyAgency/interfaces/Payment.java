package interfaces;

public interface Payment {
	public void pay(int price);
}
